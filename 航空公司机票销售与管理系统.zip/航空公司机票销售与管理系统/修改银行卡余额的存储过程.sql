-- 修改银行卡余额的存储过程
DELIMITER $$

CREATE PROCEDURE update_bank_balance(
    IN p_B_U_CARD VARCHAR(20),
    IN p_new_B_BALANCE DECIMAL(10,2)
)
BEGIN
    UPDATE bank
    SET B_BALANCE = p_new_B_BALANCE
    WHERE B_U_CARD = p_B_U_CARD;
END $$

DELIMITER ;
