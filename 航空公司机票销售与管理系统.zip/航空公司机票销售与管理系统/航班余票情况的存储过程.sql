-- 查询航班余票情况的存储过程
DELIMITER $$

CREATE PROCEDURE check_available_seats(
    IN p_F_NUMBER VARCHAR(20)
)
BEGIN
    -- 查询可用座位数
    SELECT 
        s.S_TYPE AS Seat_Type, 		-- 显示座位类型
        s.S_NUMBER AS Total_Seats,  -- 显示总座位数
        (s.S_NUMBER - IFNULL(t.Sold_Seats, 0)) AS Available_Seats  -- 计算并显示可用座位数
    FROM seat s
    LEFT JOIN (
	-- 子查询：统计每种座位类型已售出的座位数
        SELECT 
            t_f_number,
            t_type,
            COUNT(*) AS Sold_Seats		-- 已售座位数
        FROM tickets
        WHERE t_f_number = p_F_NUMBER		-- 筛选输入的航班号
        GROUP BY t_f_number, t_type 			-- 按航班号和座位类型分组
    ) t ON s.F_NUMBER = t.t_f_number AND s.S_TYPE = t.t_type
    WHERE s.F_NUMBER = p_F_NUMBER;		-- 筛选输入的航班号
END $$

DELIMITER ;
