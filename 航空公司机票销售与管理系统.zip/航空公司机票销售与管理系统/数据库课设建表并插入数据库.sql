/*
SQLyog Ultimate v12.14 (64 bit)
MySQL - 5.7.23 : Database - db_plane
*********************************************************************
*/


/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `bank` */

DROP TABLE IF EXISTS `bank`;

CREATE TABLE `bank` (
  `B_ID` decimal(8,0) NOT NULL,
  `B_NAME` varchar(30) NOT NULL,
  `B_U_NAME` varchar(20) NOT NULL,
  `B_U_CARD` varchar(20) DEFAULT NULL,
  `B_ACCOUNT` varchar(20) DEFAULT NULL,
  `B_BALANCE` varchar(20) NOT NULL,
  PRIMARY KEY (`B_ID`),
  FOREIGN KEY (`D_UID`) REFERENCES `users`(`U_ID`),
  FOREIGN KEY (`D_TID`) REFERENCES `tickets`(`t_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bank` */

insert  into `bank`(`B_ID`,`B_NAME`,`B_U_NAME`,`B_U_CARD`,`B_ACCOUNT`,`B_BALANCE`) values 

('1','中国银行','马俐娜','430421199110083713','6222021913002785906','92520.0'),

('2','中国邮政银行','欧阳健','430421199110083710','6222021913002776580','100000'),

('3','中国工商银行','刘程','430421199110083718','62220219130003300133','5000'),

('4','中国建设银行','秦国文','430421199110083715','6222021913002200122','15000'),

('5','中国银行','明礼馨德','622921199104052624','622921199104052624','6221322.0'),

('6','中国银行','张三','430421199110083719','622921199104052628','9.9998999E7');

/*Table structure for table `deal_log` */

DROP TABLE IF EXISTS `deal_log`;

CREATE TABLE `deal_log` (
  `D_NUMBER` decimal(8,0) NOT NULL,
  `D_UID` varchar(20) DEFAULT NULL,
  `D_OPERTYPE` varchar(20) DEFAULT NULL,
  `D_TID` varchar(100) DEFAULT NULL,
  `D_TIME` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`D_NUMBER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `deal_log` */

/*Table structure for table `flight_addr` */

DROP TABLE IF EXISTS `flight_addr`;

CREATE TABLE `flight_addr` (
  `a_id` varchar(20) NOT NULL,
  `a_city` varchar(20) NOT NULL,
  `a_air` varchar(50) NOT NULL,
  PRIMARY KEY (`a_id`),
  UNIQUE KEY `a_air` (`a_air`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `flight_addr` */

insert  into `flight_addr`(`a_id`,`a_city`,`a_air`) values 

('ct102','长沙','黄花机场'),

('ct103','怀化','芷江机场'),

('ct104','北京','北京首都国际机场'),

('ct105','北京','北京南苑国际机场'),

('ct106','上海','浦东机场'),

('ct107','广州','广州白云机场');

/*Table structure for table `flight_info` */

DROP TABLE IF EXISTS `flight_info`;

CREATE TABLE `flight_info` (
  `F_NUMBER` varchar(30) NOT NULL,
  `F_TYPE` varchar(20) NOT NULL,
  `F_START_TIME` varchar(40) NOT NULL,
  `F_END_TIME` varchar(40) NOT NULL,
  `F_START` varchar(20) NOT NULL,
  `F_END` varchar(20) NOT NULL,
  `F_COMPANY` varchar(30) NOT NULL,
  PRIMARY KEY (`F_NUMBER`),
  FOREIGN KEY (`F_START`) REFERENCES `flight_addr`(`a_id`),
  FOREIGN KEY (`F_END`) REFERENCES `flight_addr`(`a_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `flight_info` */

insert  into `flight_info`(`F_NUMBER`,`F_TYPE`,`F_START_TIME`,`F_END_TIME`,`F_START`,`F_END`,`F_COMPANY`) values 

('A9999','E8888','15:20','17:20','ct105','ct107','中国国际航空'),

('CA1893','C1024','07:00','09:20','ct102','ct103','中国国际航空'),

('CA1894','C1024','13:35','15:55','ct103','ct102','中国国际航空'),

('CZ3809','H78','10:20','12:40','ct101','ct104','南方航空'),

('CZ3810','H78','15:00','17:20','ct104','ct101','南方航空'),

('MU5331','M736','08:00','10:36','ct101','ct103','东方航空'),

('MU5332','M736','13:00','15:36','ct103','ct101','东方航空'),

('MU5367','M738','09:00','09:25','ct101','ct102','东方航空'),

('MU5368','M738','14:00','14:25','ct102','ct101','东方航空'),

('ZR808080','H189','08:00','11:00','ct105','ct102','中国国际航空');

/*Table structure for table `orders` */

DROP TABLE IF EXISTS `orders`;

CREATE TABLE `orders` (
  `O_ID` varchar(100) DEFAULT NULL,
  `O_UID` varchar(20) DEFAULT NULL,
  `O_TID` varchar(40) DEFAULT NULL,
  `O_TIME` varchar(40) DEFAULT NULL,
  FOREIGN KEY (`O_UID`) REFERENCES `users`(`U_ID`),
  FOREIGN KEY (`O_TID`) REFERENCES `tickets`(`t_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `orders` */

insert  into `orders`(`O_ID`,`O_UID`,`O_TID`,`O_TIME`) values 

('O2657','malina',NULL,'2018-02-06'),

('O262','malina','e1318','2018-02-06'),

('O6165','llq','e9605','2018-02-06'),

('O1965','zhangbankbank','e9728','2020-07-06');

/*Table structure for table `seat` */

DROP TABLE IF EXISTS `seat`;

CREATE TABLE `seat` (
  `F_NUMBER` varchar(20) DEFAULT NULL,
  `S_TYPE` varchar(30) NOT NULL,
  `S_NUMBER` varchar(10) NOT NULL,
  `S_PRICE` decimal(10,2) NOT NULL,
  FOREIGN KEY (`F_NUMBER`) REFERENCES `flight_info`(`F_NUMBER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `seat` */

insert  into `seat`(`F_NUMBER`,`S_TYPE`,`S_NUMBER`,`S_PRICE`) values 

('MU5367','商务舱','30','120.00'),

('MU5367','经济舱','80','100.00'),

('MU5367','头等舱','50','150.00'),

('MU5368','商务舱','30','120.00'),

('MU5368','经济舱','80','100.00'),

('MU5368','头等舱','50','150.00'),

('MU5331','商务舱','30','800.00'),

('MU5331','经济舱','75','600.00'),

('MU5331','头等舱','30','1000.00'),

('MU5332','商务舱','30','800.00'),

('MU5332','经济舱','75','600.00'),

('MU5332','头等舱','30','1000.00'),

('CZ3809','商务舱','25','900.00'),

('CZ3809','经济舱','90','750.00'),

('CZ3809','头等舱','40','1080.00'),

('CZ3810','商务舱','25','900.00'),

('CZ3810','经济舱','90','750.00'),

('CZ3810','头等舱','40','1080.00'),

('CA1893','商务舱','35','1030.00'),

('CA1893','经济舱','85','900.00'),

('CA1893','头等舱','30','1180.00'),

('CA1894','商务舱','35','1030.00'),

('CA1894','经济舱','85','900.00'),

('CA1894','头等舱','30','1180.00'),

('ZR808080','经济舱','100','300.00'),

('ZR808080','商务舱','50','500.00'),

('ZR808080','头等舱','10','1000.00'),

('A9999','经济舱','10','1000.00'),

('A9999','商务舱','10','2000.00'),

('A9999','头等舱','10','3000.00');

/*Table structure for table `state` */

DROP TABLE IF EXISTS `state`;

CREATE TABLE `state` (
  `fs_number` varchar(20) DEFAULT NULL,
  `fs_date` varchar(10) NOT NULL,
  `fs_state` varchar(800) NOT NULL,
  FOREIGN KEY (`fs_number`) REFERENCES `flight_info`(`F_NUMBER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `state` */

insert  into `state`(`fs_number`,`fs_date`,`fs_state`) values 

('CA1893','2018-02-10','延误了');

/*Table structure for table `tickets` */

DROP TABLE IF EXISTS `tickets`;

CREATE TABLE `tickets` (
  `t_id` varchar(100) NOT NULL,
  `t_f_number` varchar(30) DEFAULT NULL,
  `t_uid` varchar(20) DEFAULT NULL,
  `t_seatId` varchar(10) DEFAULT NULL,
  `t_type` varchar(20) DEFAULT NULL,
  `t_date` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`t_id`),
  FOREIGN KEY (`t_f_number`) REFERENCES `flight_info`(`F_NUMBER`),
  FOREIGN KEY (`t_uid`) REFERENCES `users`(`U_ID`),
  FOREIGN KEY (`t_seatId`) REFERENCES `seat`(`S_NUMBER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tickets` */

insert  into `tickets`(`t_id`,`t_f_number`,`t_uid`,`t_seatId`,`t_type`,`t_date`) values 

('e1318','CA1893','malina','1','经济舱','2018-02-15'),

('e4908790','MU5331','otcyan','1','头等舱','2012-12-13'),

('e4908791','MU5331','otcyan','14','头等舱','2012-12-13'),

('e9605','CA1893','llq','1','经济舱','2018-02-06'),

('e9728','A9999','test','1','经济舱','2020-07-06');

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
   `U_ID` VARCHAR(20) NOT NULL,
   `U_PASSWORD` VARCHAR(20) NOT NULL,
   `U_NAME` VARCHAR(20) NOT NULL,
   `U_SEX` VARCHAR(5) NOT NULL,
   `U_TELEPHONE` VARCHAR(20) NOT NULL,
   `U_ADDRESS` VARCHAR(100) NOT NULL,
   `U_EMAIL` VARCHAR(50) NOT NULL,
   `U_IDCARD` VARCHAR(20) DEFAULT NULL,
   `U_POWER` VARCHAR(1) NOT NULL,
   PRIMARY KEY (`U_ID`),
   CONSTRAINT `chk_u_id` CHECK (CHAR_LENGTH(`U_ID`) <= 20),
   CONSTRAINT `chk_u_password_length` CHECK (CHAR_LENGTH(`U_PASSWORD`) BETWEEN 9 AND 20),
   CONSTRAINT `chk_u_name` CHECK (CHAR_LENGTH(`U_NAME`) <= 20),
   CONSTRAINT `chk_u_telephone` CHECK (`U_TELEPHONE` REGEXP '^(0\\d{2,3}-)?(\\d{7,8})|(0?1\\d{10})$'),
   CONSTRAINT `chk_u_address` CHECK (CHAR_LENGTH(`U_ADDRESS`) <= 100),
   CONSTRAINT `chk_u_email` CHECK (`U_EMAIL` REGEXP '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$'),
   CONSTRAINT `chk_u_idcard` CHECK (`U_IDCARD` REGEXP '^\\d{17}[0-9a-zA-Z]$' OR `U_IDCARD` IS NULL),
   CONSTRAINT `chk_u_power` CHECK (CHAR_LENGTH(`U_POWER`) = 1)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `users` */

insert  into `users`(`U_ID`,`U_PASSWORD`,`U_NAME`,`U_SEX`,`U_TELEPHONE`,`U_ADDRESS`,`U_EMAIL`,`U_IDCARD`,`U_POWER`) values 

('admin','fengjunyao','冯军遥','男','18073435677','河南南阳','fjy@qq.com','430421199110083702','1'),

('guowen','xncusehacsa','秦国文','男','18073435677','山东菏泽','qgw@qq.com','430421199110083715','0'),

('joychen','asdefwe1332','刘程','男','18073435677','广东惠州','lc@qq.com','430421199110083718','0'),

('llq','sadewe23rew','明礼馨德','男','13918621258','上海','llq@qq.com','622921199104052624','0'),

('malina','asef3ewf3we','马俐娜','女','18073435677','湖南长沙','mln@qq.com','430421199110083713','0'),

('otcyan','esf4ew34rdfgh','欧阳健','男','18073435677','山西华阴','oyj@qq.com','430421199110083710','0'),

('tiantian','sdfew43rt43','薛勇军','男','18073435677','湖北武汉','xyj@qq.com','430421199110083712','0'),

('xiaohua','asdaw3adfa','小华','男','18073435677','山西太原','xh@qq.com','430421199110083714','0'),

('zhang','123456789','张三','男','12345678910','福建厦门','zs@qq.com','430421199110083712','0');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
