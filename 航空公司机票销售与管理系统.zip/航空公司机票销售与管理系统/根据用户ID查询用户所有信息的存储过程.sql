DELIMITER //

CREATE PROCEDURE GetUserFlightInfo(
    IN userID VARCHAR(20)
)
BEGIN
    SELECT 
        u.U_NAME AS 用户名,
        u.U_TELEPHONE AS 联系电话,
        f.F_NUMBER AS 航班号,
        f.F_START_TIME AS 起飞时间,
        f.F_END_TIME AS 到达时间,
        f.F_COMPANY AS 航空公司,
        s.S_TYPE AS 座位类型,
        s.S_NUMBER AS 座位数量,
        s.S_PRICE AS 座位价格
    FROM users u
    JOIN tickets t ON u.U_ID = t.t_uid
    JOIN flight_info f ON t.t_f_number = f.F_NUMBER
    JOIN seat s ON f.F_NUMBER = s.F_NUMBER
    WHERE u.U_ID = userID;
END //

DELIMITER ;
