-- 修改某用户电话号码的存储过程
DELIMITER $$

CREATE PROCEDURE update_user_telephone(
    IN p_U_ID VARCHAR(20),
    IN p_new_U_TELEPHONE VARCHAR(20)
)
BEGIN
    UPDATE users
    SET U_TELEPHONE = p_new_U_TELEPHONE
    WHERE U_ID = p_U_ID;
END $$

DELIMITER ;
