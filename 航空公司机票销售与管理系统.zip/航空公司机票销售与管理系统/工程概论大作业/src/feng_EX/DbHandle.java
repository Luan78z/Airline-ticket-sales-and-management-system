package feng_EX;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import feng.Bean.Bank;
import feng.Bean.FlightAddr;
import feng.Bean.FlightInfo;
import feng.Bean.Seat;
import feng.Bean.User;
import feng_Panels.TicketSearchPanel;
import feng_Tools.DBHelp;

public class DbHandle {

	DBHelp dbHelp = null;
	ResultSet rs = null;

	public DbHandle() {
		dbHelp = new DBHelp();
	}

	/**
	 * �û���¼��ѯ
	 *
	 * @param sql   ��ѯ���
	 * @param paras ��ѯ����
	 * @return Object ���ز�ѯ�����û�����
	 */
	public Object loginQuery(String sql, String[] paras) {

		rs = dbHelp.query(sql, paras);
		User user = null;
		if (rs == null) {
			return null;
		}
		try {
			if (rs.next()) {
				// ��ѯ�ɹ�����װΪUser����
				user = new User(rs.getString(1), rs.getString(2), rs
						.getString(3), rs.getString(4), rs.getString(5), rs
						.getString(6), rs.getString(7), rs.getString(8), rs
						.getString(9));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			dbHelp.close();
		}
		System.out.println(user);
		return user;

	}

	/**
	 * ���²���
	 *
	 * @param sql   �������
	 * @param paras ���²���
	 * @return �Ƿ���³ɹ�
	 */
	public boolean update(String sql, String[] paras) {
		return dbHelp.update(sql, paras);
	}

	/**
	 * ��ѯ���������ַ
	 */
	public FlightAddr queryOneFlightAddr(String sql, String[] paras) {

		rs = dbHelp.query(sql, paras);
		FlightAddr fAddr = null;
		try {
			if (rs.next()) {
				fAddr = new FlightAddr(rs.getString(1), rs.getString(2), rs.getString(3));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return fAddr;
	}

	/**
	 * ͨ��ID��ѯ����
	 *
	 * @param sql      ��ѯ���
	 * @param paras    ��ѯ����
	 * @param startAddr ��ʼ��ַ
	 * @param endAddr   �յ��ַ
	 * @return ������Ϣ
	 */
	public FlightInfo queryFlightById(String sql, String[] paras, FlightAddr startAddr, FlightAddr endAddr) {

		rs = dbHelp.query(sql, paras);
		FlightInfo fInfo = null;
		try {
			if (rs.next()) {
				fInfo = new FlightInfo(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), startAddr, endAddr, rs.getString(7));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return fInfo;
	}

	/**
	 * ����ID��ѯ��λ
	 *
	 * @param sql     ��ѯ���
	 * @param paras   ��ѯ����
	 * @param fInfo   ������Ϣ
	 * @param fAddr   ��ַ��Ϣ
	 * @return ��λ�б�
	 */
	public Vector<Seat> querySeatById(String sql, String[] paras, FlightInfo fInfo, FlightAddr fAddr) {

		rs = dbHelp.query(sql, paras);
		Vector<Seat> seats = new Vector<Seat>();
		try {
			while (rs.next()) {
				Seat s = new Seat(fInfo, rs.getString(2), rs.getString(3), rs.getDouble(4));
				seats.add(s);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return seats;
	}

	/**
	 * ��ѯ�����Ϣ
	 *
	 * @param sql   ��ѯ���
	 * @param paras ��ѯ����
	 * @return �����ַ�б�
	 */
	public Vector<FlightAddr> queryMulInfo(String sql, String[] paras) {
		rs = dbHelp.query(sql, paras);
		Vector<FlightAddr> vector = new Vector<FlightAddr>();
		try {
			while (rs.next()) {
				FlightAddr fAddr = new FlightAddr(rs.getString(1), rs.getString(2), rs.getString(3));
				vector.add(fAddr);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return vector;
	}

	/**
	 * ��ѯ������Ϣ
	 */
	public Bank queryOneBank(String sql, String[] paras, User user) {

		rs = dbHelp.query(sql, paras);
		Bank bank = null;
		if (rs == null) {
			return null;
		}
		try {
			if (rs.next()) {
				bank = new Bank(rs.getInt(1), rs.getString(2), user.getU_name(), user.getU_idcard(), rs.getString(5), rs.getString(6));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			dbHelp.close();
		}
		System.out.println(user);
		return bank;
	}

	/**
	 * ��ѯ������Ϣ
	 */
	public FlightInfo queryFlightInfo(String sql, FlightAddr startCityId, FlightAddr endCityId, String str[]) {

		String[] paras = str.length == 1 ? new String[]{startCityId.getA_id(), endCityId.getA_id()} : new String[]{startCityId.getA_id(), endCityId.getA_id(), str[0], str[1]};
		rs = dbHelp.query(sql, paras);
		FlightInfo fInfo = null;
		if (rs == null) {
			return null;
		}
		try {
			if (rs.next()) {
				fInfo = new FlightInfo(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), startCityId, endCityId, rs.getString(7));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			dbHelp.close();
		}
		return fInfo;
	}

	/**
	 * ��ѯ��λ��Ϣ
	 */
	public Vector<Seat> querySeat(String sql, String[] paras, FlightInfo fInfo) {

		Vector<Seat> seats = new Vector<Seat>();
		rs = dbHelp.query(sql, paras);
		Vector<String> types = new Vector<String>(); // �洢��λ����
		try {
			while (rs.next()) {
				Seat seat = new Seat(fInfo, rs.getString(2), rs.getString(3), rs.getDouble(4));
				types.add(seat.getS_type());
				seats.add(seat);
			}
			// ����ȱʧ��λ����
			if (seats.size() < 3) {
				if (!types.contains("ͷ�Ȳ�")) {
					seats.add(new Seat(fInfo, "ͷ�Ȳ�", "--", 0));
				}
				if (!types.contains("�����")) {
					seats.add(new Seat(fInfo, "�����", "--", 0));
				}
				if (!types.contains("���ò�")) {
					seats.add(new Seat(fInfo, "���ò�", "--", 0));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				dbHelp.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return seats;
	}

	/**
	 * ��ѯ�ַ�������
	 */
	public Vector<String> queryStringVector(String sql, String[] paras) {
		rs = dbHelp.query(sql, paras);
		Vector<String> vector = new Vector<String>();
		try {
			while (rs.next()) {
				vector.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return vector;
	}

	/**
	 * ��ѯ�����ַ���
	 */
	public String queryOneString(String sql, String[] paras) {

		rs = dbHelp.query(sql, paras);

		try {
			if (rs.next()) {
				return rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			dbHelp.close();
		}
		return null;
	}

	/**
	 * ��ѯ״̬
	 */
	public Vector<Vector<String>> getState(String sql, String[] paras) {

		Vector<Vector<String>> rows = new Vector<Vector<String>>();
		rs = dbHelp.query(sql, paras);
		try {
			while (rs.next()) {
				Vector<String> row = new Vector<String>();
				row.add(rs.getString(1));
				row.add(rs.getString(2));
				row.add(rs.getString(3));
				row.add(rs.getString(4));
				row.add(rs.getString(5));
				row.add(rs.getString(6));
				row.add(rs.getString(7));
				rows.add(row);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			dbHelp.close();
		}
		return rows;
	}

}
