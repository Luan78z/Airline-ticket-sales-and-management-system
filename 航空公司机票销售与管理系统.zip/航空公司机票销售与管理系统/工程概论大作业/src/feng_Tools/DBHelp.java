package feng_Tools;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;

public class DBHelp {

    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    private String dbUrl = "jdbc:mysql://localhost:3306/db_cd?serverTimezone=GMT"; // ���ݿ����ӵ�ַ
    private String dbUserName = "root"; // �û���
    private String dbPassword = "fjy030905."; // ����
    private String jdbcName = "com.mysql.cj.jdbc.Driver"; // ��������

    /**
     * �õ�����
     * @return
     * @throws SQLException 
     * @throws ClassNotFoundException 
     */
    public static void main(String[] args) throws SQLException {
        DBHelp dp = new DBHelp();
        try {
            dp.getConnection();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Connection getConnection() throws SQLException {
        try {
            Class.forName(jdbcName); // �������ݿ�����
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            throw new SQLException("���ݿ���������ʧ��");
        }
        // ���ӵ����ݿ�
        Connection con = DriverManager.getConnection(dbUrl, dbUserName, dbPassword);
        // ������ӳɹ�����ʾ��Ϣ
        System.out.println("���ݿ����ӳɹ���");
        return con;
    }

    /**
     * ��ѯ���ݿ�
     * @param sql
     * @param paras
     * @return
     * @throws SQLException
     */
    public ResultSet query(String sql, String[] paras) {
        try {
            con = this.getConnection();
            ps = con.prepareStatement(sql);
            // Ϊ�ʺŸ�ֵ
            for (int i = 0; i < paras.length; i++) {
                ps.setString(i + 1, paras[i]);
            }
            rs = ps.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

    /**
     * ��ѯ���ݿ⣨��������
     * @param sql
     * @return
     */
    public ResultSet query(String sql) {
        try {
            con = this.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

    /**
     * ���²���������ɾ���ģ�
     * @param sql
     * @param paras
     * @return
     * @throws SQLException
     */
    public boolean update(String sql, String[] paras) {
        boolean b = false;
        try {
            con = this.getConnection();
            ps = con.prepareStatement(sql);
            for (int i = 0; i < paras.length; i++) {
                ps.setString(i + 1, paras[i]);
            }
            System.out.println(sql);
            System.out.println(Arrays.toString(paras));
            // ִ�и���
            if (ps.executeUpdate() == 1) {
                b = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            this.close();
        }
        return b;
    }

    /**
     * �ر����ݿ�����
     */
    public void close() {
        try {
            if (rs != null)
                rs.close();
            if (ps != null)
                ps.close();
            if (con != null)
                con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
