package feng_Panels;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Date;
import java.util.Vector;

import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.plaf.synth.Region;

import feng.Bean.User;
import feng.Model.CheckInfo;
import feng.Model.DataHandle;
import feng.Model.FileOperation;
import feng_EX.DbHandle;
import feng_Tools.MyLoginPanel;
import feng_Tools.Tookit;

public class LoginView extends JFrame implements MouseListener{
	
	private JTextField userNameField = null;
	private JPasswordField userPasswdField = null ;
    private  JPanel jp ;
    private FileOperation fileOperation  ;
    private Vector<String> loginNames ;
   // private JScrollPane autoTipPane ;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new LoginView().setVisible(true);
	}
	
	public LoginView(){
		UIManager.put("TextField.font", Tookit.getFont1()) ;
		UIManager.put("Label.font", Tookit.getFont1()) ;
		UIManager.put("Button.font", Tookit.getFont1()) ;
		fileOperation = new FileOperation();
		//从文件中加载用户
		loginNames = fileOperation.loading("工程概论大作业/path/loginName") ;
		this.init();
	}

	private void init() {
		//顶部面板
		JPanel top = new JPanel() ;
		this.add(top,BorderLayout.NORTH) ;
		//底部面板
		JPanel buttom = new JPanel(new BorderLayout()) ;
		//左侧
		buttom.add(this.leftPanel()) ;
		//右侧
		buttom.add(this.rightPanel(),BorderLayout.EAST);
		 
		this.add(buttom) ;
		this.setSize(823, 500) ;
		this.setLocationRelativeTo(null) ;
		this.setResizable(false) ;
		this.setTitle("机票预订系统") ;
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
	}
	/**
	 * 创建左侧登录面板
	 * @return
	 */
	public JPanel leftPanel(){
		JPanel jPanel = new JPanel(new BorderLayout()) ;
		//顶部
		JLabel jLogin = new JLabel(new ImageIcon("工程概论大作业/image/用户登录.jpg"),JLabel.CENTER) ;
		jPanel.add(jLogin,BorderLayout.NORTH) ;//第一个jlable
		//中间
		MyLoginPanel myPanel = new MyLoginPanel() ;
		myPanel.setLayout(null) ;
	
		final JLabel userName = new JLabel("用户名",JLabel.CENTER);
		userName.setBounds(135, 70, 65, 15) ;
		userName.setFont(Tookit.getFont1()) ;
		userName.setForeground(Color.WHITE);
		myPanel.add(userName) ;
		//第一行输入用户名jlabel
		jp = new JPanel() ;
		jp.setOpaque(false) ;
		jp.setBounds(200, 89, 140, 200) ;
		myPanel.add(jp) ;
		userNameField = new JTextField(12) ;
		userNameField.setBounds(200, 68, 140, 21) ;
		
		userNameField.getDocument().addDocumentListener(new DocumentListener() {
						
			@Override
			public void removeUpdate(DocumentEvent e) {
				//每删除一个字符
				LoginView.this.autoTip() ;
			}
			
			@Override
			public void insertUpdate(DocumentEvent e) {
				
				LoginView.this.autoTip() ;
			}
			
			@Override
			public void changedUpdate(DocumentEvent e) {
					
			}
		}) ;
		
		myPanel.add(userNameField) ;
		if(userNameField.getText().trim().equals("")){
			
		}
//		center.add(userName) ;
//		center.add(userNameField) ;
		JLabel userPasswd = new JLabel("密    码",JLabel.CENTER) ;
		userPasswd.setFont(Tookit.getFont1()) ;
		userPasswd.setBounds(135, 124, 65, 15) ;
		userPasswd.setForeground(Color.WHITE);
		userPasswdField = new JPasswordField(12) ;
		userPasswdField.setBounds(200, 124, 140, 21) ;
		myPanel.add(userPasswd) ;
		myPanel.add(userPasswdField) ;
		
		JLabel userGrade = new JLabel("用户类别",JLabel.CENTER) ;
		userGrade.setFont(Tookit.getFont1()) ;
		userGrade.setBounds(135, 166, 65, 15) ;
		userGrade.setForeground(Color.WHITE);
		final JComboBox jcb = new JComboBox(new String[]{"客户","管理员"}) ;
		jcb.setBounds(200, 163, 71, 27) ;
		myPanel.add(userGrade) ;
		jcb.setFont(Tookit.getFont1()) ;
		myPanel.add(jcb) ;

		JButton login = new JButton("登录");
		login.setBounds(151, 215, 81, 30) ;
		myPanel.add(login) ;
		login.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {

				//获取用户名和密码及级别
				if(userName.getText().trim().equals("") ||String.valueOf(userPasswdField.getPassword()).trim().equals("")){
					JOptionPane.showMessageDialog(LoginView.this, "用户名和密码都不能为空！") ;
					return ;
				}
				//验证数据的数据库验证  数据库处理  
				DataHandle loginHandle = new DataHandle() ;
				//权限
				String power = ((String)jcb.getSelectedItem()).equals("客户")?"0":"1" ;
				//用户名
				String userId = userNameField.getText().trim() ;
				//密码
				String userPasswd = String.valueOf(userPasswdField.getPassword()) ;
				User user = loginHandle.getUser(
						"select * from users where u_id=?",
						new String[] { userId });
				if(user!=null && user.getU_password().equals(userPasswd) && user.getU_power().equals(power)){
					//显示验证成功
					//得到用户信息
					String userName = user.getU_name() ;
					String userSex = user.getU_sex() ;
					String userCall = userSex.equals("男")?"先生":"女士" ;
					if(power.equals("0")){
						//显示客户
						JOptionPane.showMessageDialog(LoginView.this, "欢迎客户"+userName+userCall+"登录") ;
						new GuestMainView(user).setVisible(true) ;
					}else {
						JOptionPane.showMessageDialog(LoginView.this, "欢迎管理员"+userName+userCall+"登录") ;
						new MangerMainView(user).setVisible(true) ;
					}
					//登录成功  将用户名写入到文件中  
					if(!loginNames.contains(userId)){
						//显示文件中的Id是否存在
						loginNames.add(userId) ;
					}
					//更新的文件
					boolean b = fileOperation.save("工程概论大作业/path/loginName", loginNames) ;
					if(!b){
						JOptionPane.showMessageDialog(LoginView.this, "更新的文件失败");
						return ;
					}
					LoginView.this.dispose() ;
					
				}else{
					//验证失败
					JOptionPane.showMessageDialog(LoginView.this, "用户名密码或数据不匹配") ;
					userPasswdField.setText("") ;
				}
				
			}
		}) ;
		login.setPreferredSize(new Dimension(80, 30)) ;
		login.setBackground(new Color(0x71B8EC)) ;
		JButton exit = new JButton("退出");
		exit.setBounds(265, 215, 81, 30) ;
		myPanel.add(exit) ;
		exit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				//点击退出弹出一对话
				System.exit(0) ;
			}
		}) ;
		exit.setPreferredSize(new Dimension(80, 30)) ;
		exit.setBackground(new Color(46,116,188)) ;
		jPanel.add(myPanel) ;
		return jPanel ;
	}
/**
 * 左侧版本文本框自动提示
 * @return
 */
	public JPanel rightPanel(){
		
		final CardLayout card = new CardLayout() ;
		final JPanel right = new JPanel(card) ;
		right.setBorder(new TitledBorder(new EtchedBorder(), "用户注册")) ;
		right.setPreferredSize(new Dimension(269, 363)) ;
		//right.setBackground(new Color(0xFFFFCC)) ;
		
		Box box = Box.createVerticalBox() ;
		box.add(Box.createHorizontalStrut(32)) ;
		
		JLabel jLabel = new JLabel() ;
		jLabel.setText("<html>" + "<h2>用户注册</h2><hr>" +
	            "1. 请先注册<br> 2. 完成注册 <br>3. 注册用户名后不可更改<br><br> " +
	            "</html>");
		box.add(jLabel) ;
		
		JButton regist = new JButton("注册") ;
		regist.setPreferredSize(new Dimension(100, 30)) ;
		regist.setBackground(new Color(0xFFFFCC)) ;
		box.add(regist) ;
		JPanel jpOne = new JPanel() ;
		jpOne.setOpaque(false) ;
		jpOne.add(box) ;
		right.add(jpOne,"one") ;
		//�ڶ���panel
		JPanel jpTwo = new JPanel() ;
		jpTwo.setOpaque(false) ;
		jpTwo.setLayout(new BorderLayout()) ;
		String info ="<html>1. 请确认阅读并同意以下条款：<br>" +
                "2. 我们重视您的隐私，您的信息将会保密处理。<br>" +
                "3. 您的个人信息如有变更，请及时更新。<br>" +
                "4. 注册时，请提供真实且准确的信息。<br><br>" +
                "</html>";
		JLabel jLabel2 = new JLabel(info) ;
		jLabel2.setFont(Tookit.getFont1()) ;
		jpTwo.add(jLabel2) ;
		JPanel jpButton = new JPanel() ;
		jpButton.setOpaque(false) ;
		JButton accept = new JButton("同意") ;
		accept.setPreferredSize(new Dimension(100, 30)) ;
		accept.setBackground(new Color(0xFFFFCC)) ;
		jpButton.add(accept) ;
		JButton unaccept = new JButton("不同意") ;
		unaccept.setPreferredSize(new Dimension(100, 30)) ;
		unaccept.setBackground(new Color(0xFFFFCC)) ;
		jpButton.add(unaccept) ;
		jpTwo.add(jpButton,BorderLayout.SOUTH);
		right.add(new JScrollPane(jpTwo),"two") ;
		JPanel jpThree = new JPanel(new BorderLayout()) ;
		//jpThree.setOpaque(false) ;
		//jpThree.setPreferredSize(new Dimension(269,300)) ;
		JPanel infoPanel = new JPanel(new GridLayout(9, 2)) ;
		JLabel userId = new JLabel("用户名",JLabel.CENTER);
		userId.setFont(Tookit.getFont1()) ;
		infoPanel.add(userId) ;
		final JTextField userIdField = new JTextField() ;
		infoPanel.add(userIdField) ;
		JLabel userPasswd = new JLabel("密码",JLabel.CENTER);
		userPasswd.setFont(Tookit.getFont1()) ;
		infoPanel.add(userPasswd) ;
		final JPasswordField userPasswdField = new JPasswordField() ;
		infoPanel.add(userPasswdField) ;
		JLabel userPasswd1 = new JLabel("确认密码",JLabel.CENTER);
		userPasswd1.setFont(Tookit.getFont1()) ;
		infoPanel.add(userPasswd1) ;
		final JPasswordField userPasswd1Field = new JPasswordField() ;
		infoPanel.add(userPasswd1Field) ;
		JLabel userName = new JLabel("姓名",JLabel.CENTER);
		userName.setFont(Tookit.getFont1()) ;
		infoPanel.add(userName) ;
		final JTextField userNameField = new JTextField() ;
		infoPanel.add(userNameField) ;
		//�û��Ա�
		JLabel userSex = new JLabel("性别",JLabel.CENTER) ;
		userSex.setFont(Tookit.getFont1()) ;
		JPanel jSex = new JPanel() ;
		jSex.setOpaque(false) ;
		final JRadioButton boy = new JRadioButton("男") ;
		boy.setOpaque(false) ;
		boy.setFont(Tookit.getFont1()) ;
		final JRadioButton girl = new JRadioButton("女") ;
		girl.setOpaque(false) ;
		girl.setFont(Tookit.getFont1()) ;
		ButtonGroup gbGroup = new ButtonGroup();
		gbGroup.add(boy) ;
		gbGroup.add(girl) ;
		jSex.add(boy) ;
		jSex.add(girl) ;
		infoPanel.add(userSex);
		infoPanel.add(jSex) ;
		JLabel tel = new JLabel("电话号码",JLabel.CENTER);
		tel.setFont(Tookit.getFont1()) ;
		infoPanel.add(tel) ;
		final JTextField telField = new JTextField() ;
		infoPanel.add(telField) ;
		JLabel addr = new JLabel("地址",JLabel.CENTER);
		addr.setFont(Tookit.getFont1()) ;
		infoPanel.add(addr) ;
		final JTextField addrField = new JTextField() ;
		infoPanel.add(addrField) ;
		JLabel email = new JLabel("电子邮件",JLabel.CENTER);
		email.setFont(Tookit.getFont1()) ;
		infoPanel.add(email) ;
		final JTextField emailField = new JTextField() ;
		infoPanel.add(emailField) ;
		JLabel identity = new JLabel("身份证号",JLabel.CENTER);
		identity.setFont(Tookit.getFont1()) ;
		infoPanel.add(identity) ;
		final JTextField identityField = new JTextField() ;
		infoPanel.add(identityField) ;
		jpThree.add(infoPanel) ;

		JPanel subMitPanel = new JPanel() ;
		JButton submit = new JButton("提交注册信息") ;
		submit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				//获取所有输入信息
				String uId=userIdField.getText().trim();
				String uPassword=String.valueOf(userPasswdField.getPassword());
				String uName = userNameField.getText().trim();
				String uSex  = null;
				if(boy.isSelected()){
					uSex=boy.getText().trim();
				}
				if(girl.isSelected()){
					uSex=girl.getText().trim();
				}
				String uTelephone=telField.getText().trim();
				String uAddress  =addrField.getText().trim();
				String uEmail   = emailField.getText().trim();
				String uIdcard = identityField.getText().trim();
				
				//检查是否有空字段
				if(uId.isEmpty()||uPassword.isEmpty()||userPasswd1Field.getPassword().toString().equals("")||uName.isEmpty()||uSex.isEmpty()||uTelephone.isEmpty()||uAddress.isEmpty()||uEmail.isEmpty()||uIdcard.isEmpty()){
					JOptionPane.showMessageDialog(null, "所有字段均不能为空");
					return;
				}
				System.out.println(String.valueOf(userPasswd1Field.getPassword())+"-------"+uPassword);
				//检查密码是否一致
				if(String.valueOf(userPasswd1Field.getPassword()).equals(uPassword)==false){
					JOptionPane.showMessageDialog(null, "两次输入的密码不一致");
					return;
				}
				//创建User对象
				User user = new User(uId, uPassword, uName, uSex, uTelephone, uAddress, uEmail, uIdcard, "0");
				CheckInfo checkInfo =new CheckInfo() ;
				boolean b = checkInfo.checkRegistInfo(user) ;
				System.out.println(b);
				if(b==true){
					//显示确认注册成功，并将信息写入数据库
					String sql="insert into users values(?,?,?,?,?,?,?,?,?)";
					String[] ss={uId, uPassword, uName, uSex, uTelephone, uAddress, uEmail, uIdcard, 0+""};
					
					DataHandle dataHandle=new DataHandle();
					boolean iss=dataHandle.update(sql, ss);
					if(iss){
						 JOptionPane.showConfirmDialog(null, "注册成功，是否返回？");
						card.show(right, "one") ;
					}else{
						JOptionPane.showMessageDialog(null, "注册失败！");
						return;
					}
				}	
			}
		}) ;
		submit.setFont(Tookit.getFont1()) ;
		//submit.setPreferredSize(new Dimension(100, 30)) ;
		submit.setBackground(new Color(0xFFFFCC)) ;
		subMitPanel.add(submit) ;
		JButton reset = new JButton("重置") ;
		reset.setFont(Tookit.getFont1()) ;
		reset.setPreferredSize(new Dimension(100, 30)) ;
		reset.setBackground(new Color(0xFFFFCC)) ;
		subMitPanel.add(reset) ;
		jpThree.add(subMitPanel,BorderLayout.SOUTH) ;
		right.add(jpThree,"three") ;
		
		reset.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				userIdField.setText("") ;
				userNameField.setText("") ;
				userPasswdField.setText("") ;
				userPasswd1Field.setText("") ;
				telField.setText("") ;
				addrField.setText("") ;
				emailField.setText("") ;
				identityField.setText("") ;
			}
		}) ;
		regist.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				//显示注册页面
				card.show(right, "two") ;
			}
		}) ;
		accept.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				card.show(right, "three") ;
			}
		}) ;
		unaccept.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				card.show(right, "one") ;
			}
		}) ;
		return right ;
	}
	
	public void autoTip(){
		System.out.println("===");
		// 清空提示框中的内容
		jp.removeAll();
		// 获取文本框中的内容
		String str = userNameField.getText().trim() ;
		
		for(String loginName :loginNames){
			if(loginName.startsWith(str) && !str.equals("")){
				//创建一个新的jlabel
				JLabel jLabel = new JLabel(loginName) ;
				jLabel.addMouseListener(LoginView.this) ;
				jLabel.setPreferredSize(new Dimension(140, 20));
				//jLabels.add(jLabel) ;
				jp.add(jLabel) ;	
			}
		}
		jp.repaint() ;
		//autoTipPane.repaint() ;
		jp.validate() ;//刷新面板
	//	autoTipPane.validate() ;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		
		userNameField.setText(((JLabel)e.getSource()).getText()) ;
		//清空提示框	
		jp.removeAll() ;
		this.remove(jp) ;
		this.repaint() ;
		this.validate() ;

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		JLabel jLabel = (JLabel)e.getSource() ;
		jLabel.setForeground(Tookit.getColor()) ;
		jLabel.setCursor(new Cursor(Cursor.HAND_CURSOR)) ;
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		JLabel jLabel = (JLabel)e.getSource() ;
		jLabel.setForeground(Color.black) ;
		jLabel.setCursor(new Cursor(Cursor.DEFAULT_CURSOR)) ;
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
