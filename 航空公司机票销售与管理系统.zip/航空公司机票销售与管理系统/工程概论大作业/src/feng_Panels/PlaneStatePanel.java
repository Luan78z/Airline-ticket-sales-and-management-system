package feng_Panels;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import feng.Bean.Bank;
import feng.Bean.FlightInfo;
import feng.Bean.Seat;
import feng.Bean.User;
import feng_EX.DbHandle;
import feng_Tools.ImagePanel;
import feng_Tools.Tookit;
import javafx.scene.image.Image;
import feng.Model.DataHandle;
import feng.Model.FlightStateModel;
import feng.Model.SearchTableModel;

public class PlaneStatePanel extends JPanel implements ActionListener{
	
	static HashMap<String, Bank> map= null ;//һ��ƱId����ʲô �����˺���� 
	private CardLayout card = null ;
	private Vector<Vector<String>> states =null;
	private FlightStateModel fModel=null;
	private JTextField jtf1,jtf2,jtf3;
	private JLabel jl1 ,jl2,jl3;
	private String currenTime ;
	private JButton queryButton,backButton,resetButton ;
	private JScrollPane jsp ;
	private JTable jTable;
	private DbHandle dbHandle;
	private  String[] paras= null;
	private Thread thread = null ;

	private ImagePanel iPanel = null ;
	public PlaneStatePanel(){
		card = new CardLayout() ;
		dbHandle = new DbHandle();
		this.init();
	}
	private void init() {
		try {
			iPanel = new ImagePanel(ImageIO.read(new File("���̸��۴���ҵ/image/��������.jpg")),new Dimension(1280,800)) ;
			iPanel.setLayout(card);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		iPanel.add(this.onePanel(),"one") ;
		iPanel.add(this.twoPanel(),"two") ;
		
	}
	public JPanel getJPanel() {
		return iPanel;
	}

	public JPanel onePanel(){
		JPanel jPanel = new JPanel(new BorderLayout()) ;
		jPanel.setOpaque(false) ;
		//���Ʊ���
		JPanel north = new JPanel() ;
		north.setPreferredSize(new Dimension(1028,145)) ;
		north.setBackground(new Color(0xA7C8F3));
		JLabel jlTitle = new JLabel("���ද̬");
		jlTitle.setFont(new Font("����", Font.PLAIN, 50));
		jlTitle.setForeground(Color.white);
		north.add(jlTitle);
		jPanel.add(north,BorderLayout.NORTH) ;
		
		JPanel center = new JPanel(null) ;
		center.setOpaque(false) ;
		
		jl1= new JLabel("�������У�");
		jl1.setBounds(200, 20, 74, 20) ;
		jl1.setFont(Tookit.getFont1()) ;
		jtf1= new JTextField(12) ;
		jtf1.setBounds(275, 20, 130, 20) ;
	    jl2 = new JLabel("������У�");
		jl2.setBounds(200, 70, 74, 20) ;
		jl2.setFont(Tookit.getFont1()) ;
	    jtf2 = new JTextField() ;
		jtf2.setBounds(275, 70, 130, 20) ;
		jl3 = new JLabel("�������ڣ�",JLabel.RIGHT);
		jl3.setFont(Tookit.getFont1()) ;
		jl3.setBounds(200, 120, 74, 20) ;
		jtf3 = new JTextField(currenTime) ;
		jtf3.setBounds(275, 120, 130, 20) ;
		
		
		
		queryButton = new JButton("��ʼ��ѯ");
		queryButton.addActionListener(this) ;
		queryButton.setFont(Tookit.getFont1()) ;
		queryButton.setBounds(180, 220, 120, 30) ;
		queryButton.setBackground(new Color(0xA9CAF3)) ;
		resetButton = new JButton("���²�ѯ") ;
		resetButton.addActionListener(this) ;
		resetButton.setBackground(new Color(0xA9CAF3)) ;
		resetButton.setFont(Tookit.getFont1()) ;
		resetButton.setBounds(320, 220, 120, 30) ;
		
		center.add(jl1) ;
		center.add(jtf1) ;
		center.add(jl2) ;
		center.add(jtf2) ;
		center.add(jl3) ;
		center.add(jtf3) ;
		center.add(queryButton) ;
		center.add(resetButton) ;
		
		jPanel.add(center) ;
		//�����ϱ�
		JPanel south = new JPanel() ;
		south.setPreferredSize(new Dimension(1028,200)) ;
		south.setOpaque(false) ;
		jPanel.add(south,BorderLayout.SOUTH) ;
		
		return jPanel ;
	}

	
public JPanel twoPanel(){	
		
		JPanel jp = new JPanel(new BorderLayout());
		jp.setOpaque(false) ;
		//����
		JPanel north = new JPanel() ;
		north.setOpaque(false) ;
		north.setPreferredSize(new Dimension(Tookit.getScreen().width,94)) ;
		jp.add(north,BorderLayout.NORTH) ;
		
		
		//�м�
		JPanel center = new JPanel(new BorderLayout());
		center.setOpaque(false) ;
		JLabel jlName = new JLabel("����״̬��Ϣ",JLabel.CENTER);
		jlName.setFont(Tookit.getFont5()) ;
		jlName.setForeground(Color.yellow);
		center.add(jlName,BorderLayout.NORTH) ;
		//����JTable
		
		
//		new Thread(){
//			public void run() {
//				//����model����
//				
//				try {
//					Thread.sleep(1000);
//				} catch (InterruptedException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			};
//		}.start();
		
		jsp = new JScrollPane() ;
		//jScrollPane����͸��
		jsp.setOpaque(false) ;
		jsp.getViewport().setOpaque(false) ;
		center.add(jsp) ;
		jp.add(center) ;
		
		JPanel jpBottom = new JPanel() ;
		jpBottom.setOpaque(false) ;
//		unButton = new JButton("��  ��");
//		unButton.addActionListener(this) ;
//		unButton.setFont(Tookit.getFont1()) ;
//		unButton.setBackground(new Color(0xA9CAF3)) ;
		backButton = new JButton("��   ��") ;
		backButton.addActionListener(this) ;
		backButton.setBackground(new Color(0xA9CAF3)) ;
		backButton.setFont(Tookit.getFont1()) ;
//		jpBottom.add(unButton) ;
		jpBottom.add(backButton) ;
		jp.add(jpBottom,BorderLayout.SOUTH) ;
		return jp ;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// ��һ������еĲ�ѯ
		if(e.getSource()==queryButton){
			String startCity = jtf1.getText();
			String endCity = jtf2.getText();
			String stateDate = jtf3.getText();
			StringBuffer sb = new StringBuffer();
			int index =sb.length() ;
			sb.delete(0,index);
			sb.append("select fi.F_number, fa.a_city,fa1.a_city,s.fs_date,s.fs_state ");
			sb.append("from  flight_info fi,flight_addr  fa, flight_addr  fa1,state s ");
			sb.append("where s.fs_number=fi.f_number  and  fa.a_id= fi.f_start and fa1.a_id=fi.f_end ");
			//����û�ʲô��û�������ʾ���еĶ�̬��Ϣ
			if(jtf1.getText().trim().equals("")||jtf2.getText().trim().equals("")||jtf3.getText().trim().equals("")){
				sb.append("and 1=?");
				paras=new String[]{"1"};
			}else{
				//������ѯ
				sb.append("and fa.a_city=? and fa1.a_city=? and s.fs_date=?");
				paras = new String[]{startCity,endCity,stateDate};
			final String sql = String.valueOf(sb);
			thread =new Thread(new Runnable() {
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					while(true){
						states = new DbHandle().getState(sql,paras) ;
						fModel = new FlightStateModel(states) ;
						jTable = new JTable() ;
						jTable.setModel(fModel) ;//......
						jTable.setRowHeight(60) ;
						jTable.setBackground(new Color(0xA9CAF3)) ;
						//�����õ����ݷŵ�������
						jsp.setViewportView(jTable) ;
						//�ػ�
//						jsp.validate() ;
//						jsp.repaint() ;
						try {
							Thread.sleep(1000) ;
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						//�Ƴ����
					}
				}
			}) ;
			thread.start() ;
//			new Thread(){
//				public void run() {
//					//����model����
//					//�õ� Vector<Vector<String>> states 
//					while(true){
//						states = new DbHandle().getState(sql,paras) ;
//						fModel = new FlightStateModel(states) ;
//						jTable = new JTable() ;
//						jTable.setModel(fModel) ;//......
//						jTable.setRowHeight(60) ;
//						jTable.setBackground(new Color(0xA9CAF3)) ;
//						//�����õ����ݷŵ�������
//						jsp.setViewportView(jTable) ;
//						//�ػ�
////						jsp.validate() ;f
////						jsp.repaint() ;
//						try {
//							Thread.sleep(1000) ;
//						} catch (InterruptedException e) {
//							// TODO Auto-generated catch block
//							e.printStackTrace();
//						}
//						//�Ƴ����
//					}
//				};
//			}.start();
			card.show(iPanel, "two") ;
			
		}
		//��һ������е�����
		if(e.getSource()==resetButton){
			jtf1.setText("");
			jtf2.setText("");
			jtf3.setText("");
		}
		//�ڶ�������еķ���
		if(e.getSource()==backButton){
			this.clear();
			thread.stop() ;
			card.show(iPanel, "one");
			}
		}
	}
	public void clear(){
		jtf1.setText("");
		jtf2.setText("");
		jtf3.setText("");
	}
	


}
