package feng.Model;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.table.AbstractTableModel;

import feng_EX.DbHandle;
import feng_Tools.DBHelp;

public class FlightStateModel extends AbstractTableModel{

	//ÿһ��
	String[] col = {"<html><font size=5>�����</font></html>",
			"<html><font size=5>��ʼ����</font></html>",
			"<html><font size=5>�������</font></html>",
			"<html><font size=5>��̬����</font></html>",
			"<html><font size=5>���ද̬</font></html>"} ;
	//ÿһ��
	Vector<Vector<String>> rows = null ;	
	
	public  FlightStateModel(Vector<Vector<String>> rows){
		this.rows=rows;
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return col.length;
	}

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return rows.size();
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		return ((Vector)rows.get(rowIndex)).get(columnIndex);
	}

	@Override
	public String getColumnName(int column) {
		// TODO Auto-generated method stub
		return col[column];
	}
	
	

	
}
